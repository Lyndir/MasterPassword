/* A default configuration for FreeBSD, used if there is no config.h. */

#define HAVE_POSIX_MEMALIGN 1
#define HAVE_SYSCTL_HW_USERMEM 1
#define HAVE_CLOCK_GETTIME 1
#define HAVE_SYS_PARAM_H 1
